import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Play, RotateCcw, Volume2, VolumeX, Info } from 'lucide-react';

interface Player {
  id: number;
  x: number;
  y: number;
  position: 'left' | 'center' | 'right';
  reactionDelay: number;
}

interface Ball {
  x: number;
  y: number;
  direction: 'left' | 'center' | 'right';
  moving: boolean;
  speed: number;
  power: 'soft' | 'normal' | 'fast';
  drift: number;
}

type GamePhase = 'start' | 'info' | 'countdown' | 'player-serve' | 'player-choose-power' | 'ball-rolling-to-bot' | 'bot-defend-result' | 'bot-serve-prep' | 'bot-serve' | 'ball-rolling-to-player' | 'player-defend' | 'player-defend-result' | 'goal' | 'blocked' | 'game-over';

const GoalballGame: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animationFrameRef = useRef<number>();
  
  const [gamePhase, setGamePhase] = useState<GamePhase>('start');
  const [playerScore, setPlayerScore] = useState(0);
  const [botScore, setBotScore] = useState(0);
  const [countdown, setCountdown] = useState(3);
  const [selectedPlayer, setSelectedPlayer] = useState<number | null>(null);
  const [ballDirection, setBallDirection] = useState<'left' | 'center' | 'right' | null>(null);
  const [ballPower, setBallPower] = useState<'soft' | 'normal' | 'fast' | null>(null);
  const [defensePositions, setDefensePositions] = useState<Array<'left' | 'center' | 'right'>>(['center', 'center', 'center']);
  const [message, setMessage] = useState('');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showInfo, setShowInfo] = useState(false);
  const [ball, setBall] = useState<Ball>({ 
    x: 300, 
    y: 450, 
    direction: 'center', 
    moving: false, 
    speed: 3, 
    power: 'normal',
    drift: 0
  });
  const [botDefensePositions, setBotDefensePositions] = useState<Array<'left' | 'center' | 'right'>>(['center', 'center', 'center']);
  const [botReactionDelays, setBotReactionDelays] = useState<number[]>([0, 0, 0]);
  
  const CANVAS_WIDTH = 600;
  const CANVAS_HEIGHT = 900;
  
  // Enhanced player positions with reaction delays
  const playerTeam: Player[] = [
    { id: 1, x: 150, y: 750, position: 'left', reactionDelay: 200 },
    { id: 2, x: 300, y: 750, position: 'center', reactionDelay: 150 },
    { id: 3, x: 450, y: 750, position: 'right', reactionDelay: 200 }
  ];
  
  const botTeam: Player[] = [
    { id: 1, x: 150, y: 150, position: 'left', reactionDelay: 300 },
    { id: 2, x: 300, y: 150, position: 'center', reactionDelay: 250 },
    { id: 3, x: 450, y: 150, position: 'right', reactionDelay: 300 }
  ];

  // Enhanced sound generation with directional audio
  const playBellSound = useCallback((direction: 'left' | 'center' | 'right', power: 'soft' | 'normal' | 'fast' = 'normal') => {
    if (!soundEnabled || !audioContextRef.current) return;
    
    const ctx = audioContextRef.current;
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    const panNode = ctx.createStereoPanner();
    
    oscillator.connect(gainNode);
    gainNode.connect(panNode);
    panNode.connect(ctx.destination);
    
    // Set frequency based on power
    const baseFreq = power === 'soft' ? 600 : power === 'fast' ? 1000 : 800;
    oscillator.frequency.setValueAtTime(baseFreq, ctx.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(baseFreq * 0.5, ctx.currentTime + 0.4);
    
    // Set pan based on direction
    const panValue = direction === 'left' ? -0.8 : direction === 'right' ? 0.8 : 0;
    panNode.pan.setValueAtTime(panValue, ctx.currentTime);
    
    // Set volume based on power
    const volume = power === 'soft' ? 0.15 : power === 'fast' ? 0.4 : 0.25;
    gainNode.gain.setValueAtTime(volume, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
    
    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + 0.4);
  }, [soundEnabled]);

  const initAudio = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  // Enhanced game drawing with lanes and better visuals
  const drawGame = (ctx: CanvasRenderingContext2D) => {
    // Clear canvas
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    
    // Draw court background
    ctx.fillStyle = '#1e3a8a';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    
    // Draw lane dividers
    ctx.strokeStyle = '#3b82f6';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);
    
    // Left lane divider
    ctx.beginPath();
    ctx.moveTo(200, 0);
    ctx.lineTo(200, CANVAS_HEIGHT);
    ctx.stroke();
    
    // Right lane divider
    ctx.beginPath();
    ctx.moveTo(400, 0);
    ctx.lineTo(400, CANVAS_HEIGHT);
    ctx.stroke();
    
    ctx.setLineDash([]);
    
    // Draw court lines
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    
    // Goal lines
    ctx.beginPath();
    ctx.moveTo(0, 100);
    ctx.lineTo(CANVAS_WIDTH, 100);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(0, 800);
    ctx.lineTo(CANVAS_WIDTH, 800);
    ctx.stroke();
    
    // Center line
    ctx.beginPath();
    ctx.moveTo(0, 450);
    ctx.lineTo(CANVAS_WIDTH, 450);
    ctx.stroke();
    
    // Landing zone lines
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 2;
    
    ctx.beginPath();
    ctx.moveTo(0, 250);
    ctx.lineTo(CANVAS_WIDTH, 250);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(0, 650);
    ctx.lineTo(CANVAS_WIDTH, 650);
    ctx.stroke();
    
    // Draw lane labels
    ctx.fillStyle = '#94a3b8';
    ctx.font = '14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('LEFT', 100, 30);
    ctx.fillText('CENTER', 300, 30);
    ctx.fillText('RIGHT', 500, 30);
    
    // Draw players
    playerTeam.forEach(player => {
      const isSelected = selectedPlayer === player.id;
      const defensePos = defensePositions[player.id - 1];
      
      // Draw defense position indicator
      if (gamePhase === 'player-defend' || gamePhase === 'ball-rolling-to-player') {
        const defenseX = defensePos === 'left' ? 100 : defensePos === 'right' ? 500 : 300;
        ctx.fillStyle = '#22c55e';
        ctx.globalAlpha = 0.3;
        ctx.fillRect(defenseX - 50, player.y - 25, 100, 50);
        ctx.globalAlpha = 1;
      }
      
      ctx.fillStyle = isSelected ? '#22c55e' : '#3b82f6';
      ctx.beginPath();
      ctx.arc(player.x, player.y, 25, 0, 2 * Math.PI);
      ctx.fill();
      
      // Player number
      ctx.fillStyle = '#ffffff';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`P${player.id}`, player.x, player.y + 5);
    });
    
    botTeam.forEach((player, index) => {
      const defensePos = botDefensePositions[index];
      
      // Draw bot defense position indicator
      if (gamePhase === 'ball-rolling-to-bot' || gamePhase === 'bot-defend-result') {
        const defenseX = defensePos === 'left' ? 100 : defensePos === 'right' ? 500 : 300;
        ctx.fillStyle = '#ef4444';
        ctx.globalAlpha = 0.3;
        ctx.fillRect(defenseX - 50, player.y - 25, 100, 50);
        ctx.globalAlpha = 1;
      }
      
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(player.x, player.y, 25, 0, 2 * Math.PI);
      ctx.fill();
      
      // Player number
      ctx.fillStyle = '#ffffff';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`B${player.id}`, player.x, player.y + 5);
      
      // Show defense position during relevant phases
      if (gamePhase === 'ball-rolling-to-bot' || gamePhase === 'bot-defend-result') {
        ctx.fillStyle = '#fbbf24';
        ctx.font = '12px Arial';
        ctx.fillText(defensePos.toUpperCase(), player.x, player.y - 35);
      }
    });
    
    // Draw ball with enhanced visuals
    if (ball.moving || gamePhase.includes('serve') || gamePhase.includes('rolling')) {
      // Ball shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
      ctx.beginPath();
      ctx.arc(ball.x + 2, ball.y + 2, 15, 0, 2 * Math.PI);
      ctx.fill();
      
      // Ball
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, 15, 0, 2 * Math.PI);
      ctx.fill();
      
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Ball bells indicator
      ctx.fillStyle = '#ffffff';
      ctx.font = '10px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('♪', ball.x, ball.y + 3);
    }
  };

  // Game logic functions
  const startGame = () => {
    initAudio();
    setGamePhase('countdown');
    setCountdown(3);
    setPlayerScore(0);
    setBotScore(0);
    setMessage('');
    resetGameState();
  };

  const resetGameState = () => {
    setSelectedPlayer(null);
    setBallDirection(null);
    setBallPower(null);
    setDefensePositions(['center', 'center', 'center']);
    setBall({ 
      x: 300, 
      y: 450, 
      direction: 'center', 
      moving: false, 
      speed: 3, 
      power: 'normal',
      drift: 0
    });
  };

  const handleCountdown = () => {
    if (countdown > 1) {
      setCountdown(countdown - 1);
    } else {
      setGamePhase('player-serve');
      setMessage('Choose a player to serve the ball');
    }
  };

  const selectPlayer = (playerId: number) => {
    if (gamePhase !== 'player-serve') return;
    setSelectedPlayer(playerId);
    setMessage('Choose serve direction');
  };

  const serveDirection = (direction: 'left' | 'center' | 'right') => {
    if (gamePhase !== 'player-serve' || !selectedPlayer) return;
    
    setBallDirection(direction);
    setGamePhase('player-choose-power');
    setMessage('Choose ball power');
  };

  const servePower = (power: 'soft' | 'normal' | 'fast') => {
    if (gamePhase !== 'player-choose-power' || !selectedPlayer || !ballDirection) return;
    
    setBallPower(power);
    setGamePhase('ball-rolling-to-bot');
    setMessage('Ball is rolling... Listen for the bells!');
    
    // Generate bot defense with realistic AI
    const newBotDefense = botTeam.map((_, index) => {
      const correctGuess = Math.random() < 0.7; // 70% chance of correct guess
      if (correctGuess) {
        return ballDirection;
      } else {
        const options: Array<'left' | 'center' | 'right'> = ['left', 'center', 'right'];
        return options[Math.floor(Math.random() * options.length)];
      }
    });
    setBotDefensePositions(newBotDefense);
    
    // Set bot reaction delays
    const delays = botTeam.map(() => 200 + Math.random() * 400); // 200-600ms delay
    setBotReactionDelays(delays);
    
    const servingPlayer = playerTeam.find(p => p.id === selectedPlayer);
    if (servingPlayer) {
      const targetX = ballDirection === 'left' ? 100 : ballDirection === 'right' ? 500 : 300;
      const speed = power === 'soft' ? 2 : power === 'fast' ? 5 : 3;
      const drift = (Math.random() - 0.5) * 40; // Random drift
      
      setBall({
        x: servingPlayer.x,
        y: servingPlayer.y,
        direction: ballDirection,
        moving: true,
        speed,
        power,
        drift
      });
      
      playBellSound(ballDirection, power);
    }
  };

  const checkBotDefense = () => {
    if (!ballDirection) return;
    
    // Check if any bot defender is in the correct position with reaction time
    const isBlocked = botDefensePositions.some((pos, index) => {
      const reactionSuccess = Math.random() > (botReactionDelays[index] / 1000); // Convert to success probability
      return pos === ballDirection && reactionSuccess;
    });
    
    setGamePhase('bot-defend-result');
    
    if (isBlocked) {
      setMessage('Blocked by the defense! Bot\'s turn to serve');
      setTimeout(() => {
        setGamePhase('bot-serve-prep');
        setMessage('Bot is preparing to serve...');
        setTimeout(() => startBotServe(), 1500);
      }, 2000);
    } else {
      setMessage('Goal! Excellent serve!');
      setPlayerScore(prev => {
        const newScore = prev + 1;
        if (newScore >= 5) {
          setGamePhase('game-over');
          setMessage('You Win! 🎉 Great Goalball skills!');
          return newScore;
        } else {
          setTimeout(() => {
            setGamePhase('bot-serve-prep');
            setMessage('Bot is preparing to serve...');
            setTimeout(() => startBotServe(), 1500);
          }, 2000);
          return newScore;
        }
      });
    }
  };

  const startBotServe = () => {
    const botPlayer = Math.floor(Math.random() * 3) + 1;
    const directions: Array<'left' | 'center' | 'right'> = ['left', 'center', 'right'];
    const direction = directions[Math.floor(Math.random() * directions.length)];
    const powers: Array<'soft' | 'normal' | 'fast'> = ['soft', 'normal', 'fast'];
    const power = powers[Math.floor(Math.random() * powers.length)];
    
    setGamePhase('bot-serve');
    setMessage(`Bot Player ${botPlayer} is serving ${power} to ${direction}!`);
    setBallDirection(direction);
    setBallPower(power);
    
    const servingBot = botTeam.find(p => p.id === botPlayer);
    if (servingBot) {
      const speed = power === 'soft' ? 2 : power === 'fast' ? 5 : 3;
      const drift = (Math.random() - 0.5) * 30;
      
      setBall({
        x: servingBot.x,
        y: servingBot.y,
        direction,
        moving: true,
        speed,
        power,
        drift
      });
      
      playBellSound(direction, power);
      
      setTimeout(() => {
        setGamePhase('player-defend');
        setMessage(`Ball coming ${direction}! Position your defenders quickly!`);
      }, 800);
    }
  };

  const setPlayerDefense = () => {
    if (gamePhase !== 'player-defend') return;
    
    setGamePhase('ball-rolling-to-player');
    setMessage('Defense set! Ball is approaching...');
    
    setTimeout(() => {
      checkPlayerDefense();
    }, 1500);
  };

  const checkPlayerDefense = () => {
    if (!ballDirection) return;
    
    // Check if any player defender is in the correct position
    const isBlocked = defensePositions.includes(ballDirection);
    
    setGamePhase('player-defend-result');
    
    if (isBlocked) {
      setMessage('Great defense! You blocked the shot!');
      setTimeout(() => {
        setGamePhase('player-serve');
        resetGameState();
        setMessage('Your turn to serve!');
      }, 2000);
    } else {
      setMessage('Goal for the bot! Better luck next time.');
      setBotScore(prev => {
        const newScore = prev + 1;
        if (newScore >= 5) {
          setGamePhase('game-over');
          setMessage('Bot Wins! Keep practicing your Goalball skills!');
          return newScore;
        } else {
          setTimeout(() => {
            setGamePhase('player-serve');
            resetGameState();
            setMessage('Your turn to serve!');
          }, 2000);
          return newScore;
        }
      });
    }
  };

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const animate = () => {
      drawGame(ctx);
      
      // Animate ball
      if (ball.moving) {
        setBall(prevBall => {
          let newY = prevBall.y;
          let newX = prevBall.x;
          
          if (gamePhase === 'ball-rolling-to-bot') {
            newY = Math.max(100, prevBall.y - prevBall.speed);
            newX = prevBall.x + (prevBall.drift * 0.01);
            
            if (newY <= 100) {
              setTimeout(() => checkBotDefense(), 500);
              return { ...prevBall, y: newY, x: newX, moving: false };
            }
          } else if (gamePhase === 'bot-serve' || gamePhase === 'ball-rolling-to-player') {
            newY = Math.min(800, prevBall.y + prevBall.speed);
            newX = prevBall.x + (prevBall.drift * 0.01);
            
            if (newY >= 800 && gamePhase === 'ball-rolling-to-player') {
              return { ...prevBall, y: newY, x: newX, moving: false };
            }
          }
          
          return { ...prevBall, y: newY, x: newX };
        });
      }
      
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [ball, gamePhase, ballDirection, botDefensePositions, defensePositions]);

  // Countdown timer
  useEffect(() => {
    if (gamePhase === 'countdown') {
      const timer = setTimeout(handleCountdown, 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown, gamePhase]);

  return (
    <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4">
        <div className="flex justify-between items-center text-white">
          <div className="text-center">
            <div className="text-2xl font-bold">{playerScore}</div>
            <div className="text-sm">YOU</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold">GOALBALL</div>
            <div className="text-sm opacity-75">First to 5 wins</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{botScore}</div>
            <div className="text-sm">BOT</div>
          </div>
        </div>
      </div>

      {/* Game Canvas */}
      <div className="relative bg-gray-100">
        <canvas
          ref={canvasRef}
          width={CANVAS_WIDTH}
          height={CANVAS_HEIGHT}
          className="w-full h-auto max-h-[70vh] object-contain"
        />
        
        {/* Game overlays */}
        {gamePhase === 'start' && (
          <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
            <div className="text-center text-white p-8">
              <h2 className="text-3xl font-bold mb-4">Welcome to Goalball!</h2>
              <p className="mb-6 text-lg">Experience the Paralympic sport where sound is everything</p>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={() => setShowInfo(true)}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
                >
                  <Info size={20} />
                  Learn Rules
                </button>
                <button
                  onClick={startGame}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
                >
                  <Play size={20} />
                  Start Game
                </button>
              </div>
            </div>
          </div>
        )}

        {showInfo && (
          <div className="absolute inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white rounded-lg p-6 max-w-2xl max-h-full overflow-y-auto">
              <h3 className="text-2xl font-bold mb-4">About Goalball</h3>
              <div className="space-y-4 text-sm">
                <p><strong>Goalball</strong> is a Paralympic sport designed for athletes with visual impairments.</p>
                
                <div>
                  <h4 className="font-semibold mb-2">Key Rules:</h4>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Teams of 3 players defend a goal</li>
                    <li>Ball contains bells - players rely on sound</li>
                    <li>Players must stay in their designated areas</li>
                    <li>Ball must bounce in the landing zone</li>
                    <li>Defense requires quick reactions and positioning</li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">In This Game:</h4>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Choose your serving player and direction</li>
                    <li>Select ball power (affects speed and difficulty)</li>
                    <li>Listen for directional audio cues</li>
                    <li>Position defenders strategically</li>
                    <li>React quickly to incoming serves</li>
                  </ul>
                </div>
                
                <p className="text-xs text-gray-600">
                  This simplified version helps you understand the basics of Goalball strategy and the importance of sound in the sport.
                </p>
              </div>
              
              <button
                onClick={() => setShowInfo(false)}
                className="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold transition-colors w-full"
              >
                Got it!
              </button>
            </div>
          </div>
        )}
        
        {gamePhase === 'countdown' && (
          <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
            <div className="text-6xl font-bold text-white">{countdown}</div>
          </div>
        )}
        
        {gamePhase === 'game-over' && (
          <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
            <div className="text-center text-white p-8">
              <h2 className="text-3xl font-bold mb-4">{message}</h2>
              <div className="text-xl mb-6">Final Score: {playerScore} - {botScore}</div>
              <button
                onClick={startGame}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors mx-auto"
              >
                <RotateCcw size={20} />
                Play Again
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="p-4 bg-gray-50">
        {/* Status message */}
        <div className="text-center mb-4">
          <p className="text-lg font-medium text-gray-800">{message}</p>
        </div>

        {/* Player selection */}
        {gamePhase === 'player-serve' && !selectedPlayer && (
          <div className="mb-4">
            <p className="text-sm font-medium text-gray-600 mb-2">Select serving player:</p>
            <div className="flex gap-2 justify-center">
              {playerTeam.map(player => (
                <button
                  key={player.id}
                  onClick={() => selectPlayer(player.id)}
                  className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                >
                  Player {player.id} ({player.position})
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Direction selection */}
        {gamePhase === 'player-serve' && selectedPlayer && !ballDirection && (
          <div className="mb-4">
            <p className="text-sm font-medium text-gray-600 mb-2">Choose serve direction:</p>
            <div className="flex gap-2 justify-center">
              <button
                onClick={() => serveDirection('left')}
                className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-medium transition-colors"
              >
                ← Left Lane
              </button>
              <button
                onClick={() => serveDirection('center')}
                className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-medium transition-colors"
              >
                ↑ Center Lane
              </button>
              <button
                onClick={() => serveDirection('right')}
                className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-medium transition-colors"
              >
                Right Lane →
              </button>
            </div>
          </div>
        )}

        {/* Power selection */}
        {gamePhase === 'player-choose-power' && (
          <div className="mb-4">
            <p className="text-sm font-medium text-gray-600 mb-2">Choose ball power:</p>
            <div className="flex gap-2 justify-center">
              <button
                onClick={() => servePower('soft')}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg font-medium transition-colors text-sm"
              >
                Soft (Easy to block)
              </button>
              <button
                onClick={() => servePower('normal')}
                className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg font-medium transition-colors text-sm"
              >
                Normal
              </button>
              <button
                onClick={() => servePower('fast')}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-colors text-sm"
              >
                Fast (Hard to block)
              </button>
            </div>
          </div>
        )}

        {/* Defense positioning */}
        {gamePhase === 'player-defend' && (
          <div className="mb-4">
            <p className="text-sm font-medium text-gray-600 mb-2">Position your defenders (Ball: {ballDirection} lane):</p>
            <div className="space-y-2">
              {playerTeam.map((player, index) => (
                <div key={player.id} className="flex items-center justify-center gap-2">
                  <span className="text-sm w-16">P{player.id}:</span>
                  <button
                    onClick={() => {
                      const newPositions = [...defensePositions];
                      newPositions[index] = 'left';
                      setDefensePositions(newPositions);
                    }}
                    className={`px-3 py-1 rounded text-sm ${defensePositions[index] === 'left' 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-200 text-gray-700'} transition-colors`}
                  >
                    Left
                  </button>
                  <button
                    onClick={() => {
                      const newPositions = [...defensePositions];
                      newPositions[index] = 'center';
                      setDefensePositions(newPositions);
                    }}
                    className={`px-3 py-1 rounded text-sm ${defensePositions[index] === 'center' 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-200 text-gray-700'} transition-colors`}
                  >
                    Center
                  </button>
                  <button
                    onClick={() => {
                      const newPositions = [...defensePositions];
                      newPositions[index] = 'right';
                      setDefensePositions(newPositions);
                    }}
                    className={`px-3 py-1 rounded text-sm ${defensePositions[index] === 'right' 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-200 text-gray-700'} transition-colors`}
                  >
                    Right
                  </button>
                </div>
              ))}
              <button
                onClick={setPlayerDefense}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg font-medium transition-colors mt-2"
              >
                Set Defense
              </button>
            </div>
          </div>
        )}

        {/* Sound toggle */}
        <div className="flex justify-center">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            {soundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
            <span className="text-sm">{soundEnabled ? 'Sound On' : 'Sound Off'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default GoalballGame;