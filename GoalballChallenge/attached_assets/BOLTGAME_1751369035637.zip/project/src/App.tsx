import React from 'react';
import GoalballGame from './components/GoalballGame';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold text-white mb-2">Goalball</h1>
          <p className="text-blue-200 text-lg">Experience the Paralympic sport</p>
        </div>
        <GoalballGame />
      </div>
    </div>
  );
}

export default App;